*PADS-LIBRARY-PART-TYPES-V9*

HCNR201-300E HCNR201300E I ANA 7 1 0 0 0
TIMESTAMP 2026.10.13.12.28.59
"Mouser Part Number" 630-HCNR201-300E
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Broadcom-Avago/HCNR201-300E?qs=xnajaXqBF9%2Fpqjck28%2FBeQ%3D%3D
"Manufacturer_Name" Avago Technologies
"Manufacturer_Part_Number" HCNR201-300E
"Description" Broadcom, HCNR201-300E DC Input Photodiode Output Optocoupler, Surface Mount, 8-Pin PDIP-W
"Datasheet Link" https://datasheet.datasheetarchive.com/originals/distributors/Datasheets-6/DSA-115859.pdf
"Geometry.Height" 5mm
GATE 1 8 0
HCNR201-300E
1 0 U LED_CATHODE
2 0 U LED_ANODE
3 0 U PD1_CATHODE
4 0 U PD1_ANODE
5 0 U PD2_ANODE
6 0 U PD2_CATHODE
7 0 U NC_1
8 0 U NC_2

*END*
*REMARK* SamacSys ECAD Model
888316/1311107/2.50/8/4/Integrated Circuit
