*PADS-LIBRARY-PART-TYPES-V9*

BZX84-A3V3_215 SOT95P230X110-3N I DIO 7 1 0 0 0
TIMESTAMP 2026.10.13.12.40.48
"Mouser Part Number" 771-BZX84-A3V3,215
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Nexperia/BZX84-A3V3215?qs=mSipnS5lFm%252BDttua7uZ2ig%3D%3D
"Manufacturer_Name" Nexperia
"Manufacturer_Part_Number" BZX84-A3V3,215
"Description" NEXPERIA - BZX84-A3V3,215 - ZENER DIODE, 0.25W, 3.3V, SOT-23, REEL
"Datasheet Link" https://assets.nexperia.com/documents/data-sheet/BZX84_SER.pdf
"Geometry.Height" 1.1mm
GATE 1 3 0
BZX84-A3V3_215
1 0 U A
2 0 U N.C.
3 0 U K

*END*
*REMARK* SamacSys ECAD Model
792576/1311107/2.50/3/2/Zener Diode
