*PADS-LIBRARY-PART-TYPES-V9*

ISOUSB111DWXR SOP65P1030X260-16N I ANA 7 1 0 0 0
TIMESTAMP 2026.10.14.14.08.31
"Mouser Part Number" 595-ISOUSB111DWXR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/ISOUSB111DWXR?qs=Y0Uzf4wQF3msEozH7EwD3g%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" ISOUSB111DWXR
"Description" USB Interface IC Low emissions, full and low speed isolated USB repeater 16-SSOP -40 to 125
"Datasheet Link" https://www.ti.com/lit/ds/symlink/isousb111.pdf?ts=1669697942868&ref_url=https%253A%252F%252Fwww.ti.com%252Fproduct%252FISOUSB111%253FkeyMatch%253DISOUSB111DWXR%2526tisearch%253Dsearch-everything%2526usecase%253DOPN
"Geometry.Height" 2.6mm
GATE 1 16 0
ISOUSB111DWXR
1 0 U VBUS1
2 0 U GND1_1
3 0 U V3P3V1
4 0 U NC_1
5 0 U V2OK
6 0 U UD-
7 0 U UD+
8 0 U GND1_2
16 0 U VBUS2
15 0 U GND2_2
14 0 U V3P3V2
13 0 U NC_2
12 0 U V1OK
11 0 U DD-
10 0 U DD+
9 0 U GND2_1

*END*
*REMARK* SamacSys ECAD Model
17249297/1311107/2.50/16/3/Integrated Circuit
