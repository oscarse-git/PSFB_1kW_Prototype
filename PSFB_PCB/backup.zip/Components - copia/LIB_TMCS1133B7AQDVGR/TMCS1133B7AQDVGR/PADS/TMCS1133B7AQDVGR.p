*PADS-LIBRARY-PART-TYPES-V9*

TMCS1133B7AQDVGR TMCS1133B7AQDVGR I ANA 7 1 0 0 0
TIMESTAMP 2026.10.12.19.49.07
"Mouser Part Number" 
"Mouser Price/Stock" 
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TMCS1133B7AQDVGR
"Description" Board Mount Current Sensors +/-1300V reinforced isolation 80ARMS 1M
"Datasheet Link" https://www.ti.com/product/TMCS1133#design-development
"Geometry.Height" 2.65mm
GATE 1 10 0
TMCS1133B7AQDVGR
1 0 U IN+
2 0 U IN-
3 0 U GND
4 0 U \ALERT
5 0 U NC
6 0 U VOUT
7 0 U \OC
8 0 U VOC
9 0 U VS_1
10 0 U VS_2

*END*
*REMARK* SamacSys ECAD Model
21472271/1311107/2.50/10/3/Integrated Circuit
