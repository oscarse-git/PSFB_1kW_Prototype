*PADS-LIBRARY-PART-TYPES-V9*

OPA356AIDBVT SOT95P280X145-5N I ANA 7 1 0 0 0
TIMESTAMP 2026.10.13.12.37.28
"Mouser Part Number" 595-OPA356AIDBVT
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/OPA356AIDBVT?qs=7nS3%252BbEUL6sNJlEi0818Dw%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" OPA356AIDBVT
"Description" Texas Instruments OPA356AIDBVT Op Amp, 200MHz CMOS, Rail to Rail, 3 V, 5 V, 5-Pin SOT-23
"Datasheet Link" http://www.ti.com/lit/gpn/opa356
"Geometry.Height" 1.45mm
GATE 1 5 0
OPA356AIDBVT
1 0 U OUT
2 0 U V-
3 0 U +IN
4 0 U -IN
5 0 U V+

*END*
*REMARK* SamacSys ECAD Model
415539/1311107/2.50/5/3/Integrated Circuit
