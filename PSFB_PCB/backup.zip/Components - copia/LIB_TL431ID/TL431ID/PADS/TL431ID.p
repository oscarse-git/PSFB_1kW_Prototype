*PADS-LIBRARY-PART-TYPES-V9*

TL431ID SOIC127P600X175-8N I ANA 7 1 0 0 0
TIMESTAMP 2026.10.13.12.43.25
"Mouser Part Number" 595-TL431ID
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/TL431ID?qs=8Pd2FuFSoMGOQLhJS1fgeg%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TL431ID
"Description" 2% Accuracy Adjustable Precision Shunt Regulator
"Datasheet Link" http://www.ti.com/lit/ds/symlink/tl431.pdf
"Geometry.Height" 1.75mm
GATE 1 8 0
TL431ID
1 0 U K
2 0 U A_1
3 0 U A_2
4 0 U NC_1
8 0 U REF
7 0 U A_4
6 0 U A_3
5 0 U NC_2

*END*
*REMARK* SamacSys ECAD Model
182383/1311107/2.50/8/3/Integrated Circuit
