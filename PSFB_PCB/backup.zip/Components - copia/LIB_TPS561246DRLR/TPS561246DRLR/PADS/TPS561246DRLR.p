*PADS-LIBRARY-PART-TYPES-V9*

TPS561246DRLR SOTFL50P160X60-6N I ANA 7 1 0 0 0
TIMESTAMP 2026.10.15.17.53.56
"Mouser Part Number" 595-TPS561246DRLR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/TPS561246DRLR?qs=IKkN%2F947nfBlLn983Qr7Pw%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TPS561246DRLR
"Description" Switching Voltage Regulators 4.2V to 17V input voltage, 1A, 1.2MHz synchronous buck converter in SOT563 with FCCM mode
"Datasheet Link" https://www.ti.com/lit/ds/symlink/tps561246.pdf?ts=1736141056725&ref_url=https%253A%252F%252Fwww.ti.com%252Fproduct%252FTPS561246%252Fpart-details%252FTPS561246DRLR
"Geometry.Height" 0.6mm
GATE 1 6 0
TPS561246DRLR
1 0 U VIN
2 0 U SW
3 0 U GND
4 0 U BST
5 0 U EN
6 0 U FB

*END*
*REMARK* SamacSys ECAD Model
20276016/1311107/2.50/6/3/Integrated Circuit
