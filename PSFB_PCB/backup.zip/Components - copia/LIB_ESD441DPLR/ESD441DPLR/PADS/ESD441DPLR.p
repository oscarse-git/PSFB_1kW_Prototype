*PADS-LIBRARY-PART-TYPES-V9*

ESD441DPLR ESD441DPLR I DIO 7 1 0 0 0
TIMESTAMP 2026.10.14.19.06.11
"Mouser Part Number" 595-ESD441DPLR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/ESD441DPLR?qs=1Kr7Jg1SGW9UQFJqGMkN7Q%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" ESD441DPLR
"Description" ESD Suppressors / TVS Diodes 1-pF, 5.5-V, 30-KV ESD protection device in 0201 package 2-X2SON -40 to 125
"Datasheet Link" https://www.ti.com/lit/ds/symlink/esd441.pdf?ts=1730589139389&ref_url=https%253A%252F%252Fapp.ultralibrarian.com%252F
"Geometry.Height" 0.32mm
GATE 1 2 0
ESD441DPLR
1 0 U K
2 0 U A

*END*
*REMARK* SamacSys ECAD Model
19063521/1311107/2.50/2/3/TVS Diode (Uni-directional)
