*PADS-LIBRARY-PART-TYPES-V9*

LTC3639HMSE#PBF LTC3639HMSEPBF I ANA 7 1 0 0 0
TIMESTAMP 2026.10.13.16.57.00
"Mouser Part Number" 584-LTC3639HMSE#PBF
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Analog-Devices/LTC3639HMSEPBF?qs=hVkxg5c3xu91%2FQQCRu4j6Q%3D%3D
"Manufacturer_Name" Analog Devices
"Manufacturer_Part_Number" LTC3639HMSE#PBF
"Description" High Efficiency, 150V 100mA Synchronous Step-Down Regulator
"Datasheet Link" https://www.analog.com/media/en/technical-documentation/data-sheets/3639fd.pdf
"Geometry.Height" 1.1mm
GATE 1 13 0
LTC3639HMSE#PBF
1 0 U SW
3 0 U VIN
5 0 U FBO
6 0 U VPRG2
7 0 U VPRG1
8 0 U GND_1
9 0 U VFB
10 0 U SS
11 0 U ISET
12 0 U OVLO
14 0 U RUN
16 0 U GND_2
17 0 U GND_3

*END*
*REMARK* SamacSys ECAD Model
2192574/1311107/2.50/13/2/Integrated Circuit
